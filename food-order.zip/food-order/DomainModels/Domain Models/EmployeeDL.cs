﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Models
{
    class EmployeeDL
    {

        public static List<Employee> employee = new List<Employee>();
       // void addemployee(Employee e1);
       // void deleteemployee(Employee e1);
    }
}
