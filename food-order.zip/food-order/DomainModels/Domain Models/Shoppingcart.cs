﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Models
{
    class Shoppingcart
    {

        public static List<Product> items = new List<Product>();
        //void addItems(Product t);
        //void deleteItems(Product t);
    }
}
