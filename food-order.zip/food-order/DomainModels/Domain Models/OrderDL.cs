﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Models
{
    class OrderDL
    {

        public static List<Order> Order = new List<Order>();
        // void confirmOrder();
        // void deleteOrder();
    }
}
